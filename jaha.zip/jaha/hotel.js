rooms = ["2","3"];

function checkIn(startC, endC){
    bookRoom(startC, endC);
}

function bookRoom(start, end){
    rooms.forEach(element => {
        if(element.end < start){
            element.signIn(start, end);
            break;
        }
    });
}

function getNumAvail(start, end){
    var nfree = 0;
    rooms.forEach(element =>{
        if(rooms.end < start){
            nfree++;
        }
    })
}