/**
 * author: Bafana Mhlahlo
 * 28 Nov 2021
 * Creating a server and send in our templates
 */

// Setting express
const express = require('express');

//express app
const app = express();

//set engine
app.set('view engine', 'ejs');

//Listening to requests
app.listen(3000, () =>{
    console.log("listening to port 3000");
});

app.get('/', (req,res) => {
    res.render('index');
});

app.get('/enquire', (req,res) =>{
    res.render('enquries');
});

app.get('/about', (req,res) => {
    res.render('about');
});

// 404 page redirect
app.use((req, res) =>{
    res.status(404).render('404');
});