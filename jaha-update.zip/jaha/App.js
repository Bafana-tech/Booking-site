/**
 * author: Bafana Mhlahlo
 * 28 Nov 2021
 * Creating a server and send in our templates
 */

// Setting express
const express = require('express');

//express app
const app = express();

//set engine
app.set('view engine', 'ejs');

//Listening to requests
app.listen(3000, () =>{
    console.log("listening to port 3000");
});



app.get('/', (req,res) => {
    const rooms = [
        {room: 'Room 1', start: '0', end: '2' },
        {room: 'Room 2', start: '0', end: '0'},
        {room: 'Room 3', start: '0', end: '1'},
        {room: 'Room 4', start: '0', end: '5'},
];

function getNumAvail(start, end){

    var nfree = 0;
    var sum = 0;
    var i = 0;
    rooms.forEach(room =>{
        i++;

        if(room.end < start){
            nfree++;
        }
        
    });
   return nfree;
}


  //  const name = "bafama";
    res.render('index',{title: 'bnsnnm' , rooms:rooms, getNumAvail:getNumAvail});
});

app.get('/enquire', (req,res) =>{
    res.render('enquries');
});

app.get('/about', (req,res) => {
    res.render('about', {title: 'Aboutd'});
});

// 404 page redirect
app.use((req, res) =>{
    res.status(404).render('404');
});
console.log("aaa");