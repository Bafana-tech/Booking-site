var num;
var start;
var end;

function Room(starta, enda, n){
    start = starta;
    end = enda;
    num = n;
}

function Room(name){
    start = 0;
    end = 0
    num = name;
}

function signIn(starta, enda){
    this.start = starta;
    this.end = enda;
}