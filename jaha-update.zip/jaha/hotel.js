var num;
var start;
var end;

function Room(starta, enda, n){
    start = starta;
    end = enda;
    num = n;
}

function Room(name){
    start = 0;
    end = 0
    num = name;
}


function signIn(starta, enda){
    this.start = starta;
    this.end = enda;
}














function checkIn(startC, endC){
    bookRoom(startC, endC);
}

function bookRoom(start, end){
    rooms.forEach(element => {
        if(element.end < start){
            element.signIn(start, end);
            //break;
        }
    });
}

rooms = [1, new Room(1,2,"2")];
function getNumAvail(start, end){

    var nfree = 0;
    var sum = 0;
    var i = 0;
    console.log(rooms[1].start);
    rooms.forEach(element =>{
        //var arr = rooms.map( v=> (v.end))[i];
        i++;

       // console.log(arr > '2021-10-11');
        if(rooms.end < start){
            //console.log(arr);
            nfree++;
        }
        
    });
    console.log(nfree);
}
checkIn(1,2);
getNumAvail(1,2);


